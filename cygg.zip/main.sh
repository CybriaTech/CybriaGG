#!/bin/bash
chmod +x caddy
./caddy run --config ./Caddyfile