# CybriaGG

🎮 CybriaGG is a proxied version of Now.GG Roblox, this proxy is not Ultraviolet and runs on Caddy, a reverse proxy service. This is to test around to try and access Now.GG and other websites without using Ultraviolet

## Active Links

https://cygg.mybooty165.repl.co/
